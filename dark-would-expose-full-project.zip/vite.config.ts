import config from "./client/vite.config.ts";
export default config;
