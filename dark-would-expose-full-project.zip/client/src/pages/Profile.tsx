import { useState } from "react";
import { useGetMe, useGetReferralStats, useListSocialLinks } from "@workspace/api-client-react";
import { Navbar } from "@/components/layout/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User as UserIcon, Copy, Crown, Share2, Shield, Calendar, ExternalLink, ChevronRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

export default function Profile() {
  const { toast } = useToast();
  const [tgIdInput, setTgIdInput] = useState("");

  const storedTgId = localStorage.getItem("dwe_user_tg_id") || "";
  const { data: user, isLoading } = useGetMe({ telegramId: storedTgId }, { query: { enabled: !!storedTgId } } as any);
  const { data: refStats } = useGetReferralStats({ telegramId: storedTgId }, { query: { enabled: !!storedTgId } } as any);
  const { data: socialLinks } = useListSocialLinks();

  const handleSetTgId = (e: React.FormEvent) => {
    e.preventDefault();
    if (tgIdInput) {
      localStorage.setItem("dwe_user_tg_id", tgIdInput);
      window.location.reload();
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied!" });
  };

  if (!storedTgId && !isLoading) {
    return (
      <>
        <main className="flex-1 flex flex-col items-center justify-center p-6 min-h-[80vh]">
          <div className="w-20 h-20 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(220,38,38,0.2)]">
            <UserIcon className="w-9 h-9 text-primary" />
          </div>
          <h1 className="text-2xl font-black tracking-tight mb-2">Connect Telegram</h1>
          <p className="text-muted-foreground text-center mb-8 max-w-xs text-sm">
            Enter your Telegram ID to access your account.
          </p>
          <form onSubmit={handleSetTgId} className="w-full max-w-xs space-y-3">
            <Input
              value={tgIdInput}
              onChange={(e) => setTgIdInput(e.target.value)}
              placeholder="Your Telegram ID"
              className="bg-card border-border text-center"
            />
            <Button type="submit" className="w-full font-bold uppercase tracking-wider">Connect</Button>
          </form>
        </main>
        <Navbar />
      </>
    );
  }

  return (
    <>
      <main className="flex-1 pb-24 md:pb-8">
        {/* Header */}
        <header className="px-4 pt-12 pb-6 border-b border-border/50 bg-card/30 backdrop-blur-xl sticky top-0 z-30">
          <h1 className="text-2xl font-black tracking-tight uppercase">Profile</h1>
        </header>

        <div className="p-4 max-w-md mx-auto space-y-5 mt-2">
          {/* User Info Card */}
          <Card className="border-border/50 bg-card/60 overflow-hidden backdrop-blur-sm">
            {/* Cover */}
            <div className="h-24 relative" style={{ background: "linear-gradient(135deg, hsl(346 87% 20%) 0%, hsl(240 10% 10%) 100%)" }}>
              <div className="absolute inset-0 opacity-20"
                style={{ backgroundImage: "radial-gradient(circle at 30% 50%, hsl(346 87% 43%) 0%, transparent 60%)" }} />
              <div className="absolute -bottom-10 left-5 w-20 h-20 rounded-full border-4 border-background bg-gradient-to-br from-card to-secondary flex items-center justify-center shadow-xl">
                {user?.isPremium
                  ? <Crown className="w-9 h-9 text-primary drop-shadow-[0_0_8px_rgba(220,38,38,0.8)]" />
                  : <UserIcon className="w-9 h-9 text-muted-foreground" />}
              </div>
              {user?.isPremium && (
                <div className="absolute top-3 right-3 text-[10px] font-black uppercase tracking-widest bg-primary/90 text-white px-2 py-1 rounded-full flex items-center gap-1">
                  <Crown className="w-3 h-3" /> VIP
                </div>
              )}
            </div>

            <CardContent className="pt-14 pb-5 px-5">
              <h2 className="text-xl font-black">{user?.firstName || 'User'}</h2>
              <p className="text-muted-foreground text-xs font-mono mt-0.5">@{user?.username || 'anonymous'}</p>

              <div className="mt-5 space-y-2">
                <div className="flex items-center justify-between p-3 bg-secondary/40 rounded-xl border border-white/5">
                  <div className="flex items-center gap-3">
                    <Shield className={`w-4 h-4 ${user?.isPremium ? 'text-primary' : 'text-muted-foreground'}`} />
                    <div>
                      <div className="text-xs font-bold uppercase tracking-wider">Status</div>
                      <div className="text-[11px] text-muted-foreground">
                        {user?.isPremium ? (user.packageType?.toUpperCase() || 'PREMIUM') : 'Free Account'}
                      </div>
                    </div>
                  </div>
                  {!user?.isPremium && (
                    <Button size="sm" asChild className="text-xs h-7 px-3">
                      <Link href="/packages">Upgrade</Link>
                    </Button>
                  )}
                </div>

                {user?.isPremium && user?.premiumExpiresAt && (
                  <div className="flex items-center gap-3 p-3 bg-primary/5 border border-primary/15 rounded-xl text-xs">
                    <Calendar className="w-4 h-4 text-primary" />
                    <div>
                      <span className="text-muted-foreground">Expires: </span>
                      <span className="font-mono font-bold">{new Date(user.premiumExpiresAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Referral Card */}
          <Card className="border-border/50 bg-card/60 backdrop-blur-sm">
            <CardContent className="p-5">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-black text-sm uppercase tracking-wider">Referral Program</h3>
                <Link href="/referral" className="text-primary text-[11px] font-bold uppercase tracking-wider hover:underline flex items-center gap-1">
                  View Tiers <ChevronRight className="w-3 h-3" />
                </Link>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-secondary/40 border border-white/5 p-3 rounded-xl text-center">
                  <div className="text-2xl font-black text-foreground">{refStats?.referralCount || 0}</div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground mt-0.5">Friends Invited</div>
                </div>
                <div className="bg-primary/10 border border-primary/20 p-3 rounded-xl text-center shadow-[0_0_15px_rgba(220,38,38,0.1)]">
                  <div className="text-2xl font-black text-primary">{refStats?.freeDaysEarned || 0}</div>
                  <div className="text-[10px] uppercase tracking-wider text-primary/80 mt-0.5">Free Days</div>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-[11px] text-muted-foreground uppercase tracking-wider">Your Invite Link</Label>
                <div className="flex gap-2">
                  <Input
                    readOnly
                    value={refStats?.referralLink || `https://t.me/darkwould_bot?start=${user?.referralCode || ''}`}
                    className="font-mono text-[11px] bg-background/50 border-border/50 flex-1"
                  />
                  <Button size="icon" variant="secondary" className="shrink-0" onClick={() => handleCopy(refStats?.referralLink || '')}>
                    <Copy className="w-4 h-4" />
                  </Button>
                  <Button size="icon" className="shrink-0" onClick={() => handleCopy(refStats?.referralLink || '')}>
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Official Channels */}
          {(socialLinks?.length ?? 0) > 0 && (
            <div>
              <h3 className="text-[11px] font-black tracking-widest text-muted-foreground uppercase mb-3 px-1">Official Channels</h3>
              <div className="space-y-2">
                {socialLinks?.filter(l => l.isActive).map(link => (
                  <a
                    key={link.id}
                    href={link.url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-3 p-4 rounded-xl bg-card/60 border border-border/50 hover:border-primary/40 transition-all group"
                  >
                    <div className="w-9 h-9 rounded-xl bg-secondary border border-white/5 flex items-center justify-center overflow-hidden shrink-0">
                      {link.logoUrl
                        ? <img src={link.logoUrl} className="w-full h-full object-cover" alt="" />
                        : <ExternalLink className="w-4 h-4 text-muted-foreground" />}
                    </div>
                    <span className="font-semibold flex-1 text-sm">{link.displayName}</span>
                    <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Admin Panel Link */}
          <div className="pt-2 pb-2">
            <Link href="/admin" className="flex items-center justify-center gap-2 text-[11px] text-muted-foreground/50 hover:text-muted-foreground transition-colors py-3">
              <Shield className="w-3 h-3" />
              <span className="uppercase tracking-widest">Admin Panel</span>
            </Link>
          </div>
        </div>
      </main>
      <Navbar />
    </>
  );
}
