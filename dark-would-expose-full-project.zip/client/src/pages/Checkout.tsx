import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useListPaymentMethods, useSubmitPayment, useListPackages, useRegisterUser, useGetPublicSettings } from "@workspace/api-client-react";
import { Navbar } from "@/components/layout/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Check,
  Copy,
  CreditCard,
  ShieldCheck,
  Smartphone,
  WalletCards,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [packageId, setPackageId] = useState<number | null>(null);
  const [selectedMethodId, setSelectedMethodId] = useState<number | null>(null);
  
  const [senderNumber, setSenderNumber] = useState("");
  const [transactionId, setTransactionId] = useState("");
  const [paymentProofUrl, setPaymentProofUrl] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);

  const registerUser = useRegisterUser();
  const { data: packages } = useListPackages();
  const { data: paymentMethods } = useListPaymentMethods();
  const { data: settings } = useGetPublicSettings();
  const currentUser = registerUser.data;
  
  const submitPayment = useSubmitPayment();

  useEffect(() => {
    let id = localStorage.getItem("dwe_user_tg_id");
    if (!id) {
      id = `web_${crypto.randomUUID()}`;
      localStorage.setItem("dwe_user_tg_id", id);
    }
    registerUser.mutate({
      data: {
        telegramId: id,
        username: localStorage.getItem("dwe_user_username") || undefined,
        firstName: localStorage.getItem("dwe_user_first_name") || undefined,
        referralCode: localStorage.getItem("dwe_referral_code") || undefined,
      },
    });
  }, []);

  const activeMethods = paymentMethods?.filter((method) => method.isActive) || [];
  const localMethods = activeMethods.filter((method) => method.type === "local");

  useEffect(() => {
    if (selectedMethodId === null && localMethods[0]) {
      setSelectedMethodId(localMethods[0].id);
    }
  }, [selectedMethodId, localMethods]);

  useEffect(() => {
    const pkgId = new URLSearchParams(window.location.search).get("package") || localStorage.getItem("dwe_checkout_pkg");
    if (pkgId) {
      setPackageId(parseInt(pkgId, 10));
    } else {
      setLocation("/packages");
    }
  }, [setLocation]);

  const selectedPackage = packages?.find(p => p.id === packageId);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied to clipboard" });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !packageId) {
      toast({ title: "Please wait", description: "Your account is still loading.", variant: "destructive" });
      return;
    }
    
    const method = paymentMethods?.find(m => m.id === selectedMethodId);
    if (!method) {
      toast({ title: "Error", description: "Please select a payment method", variant: "destructive" });
      return;
    }
    
    const amount = selectedPackage?.priceBdt;
    if (!amount) {
      toast({ title: "Package unavailable", description: "Please return and select a package again.", variant: "destructive" });
      return;
    }

    submitPayment.mutate(
      {
        data: {
          userId: currentUser.id,
          packageId,
          amount: String(amount),
          transactionId: transactionId.trim().toUpperCase(),
          userName: currentUser.firstName || currentUser.username || "",
          senderNumber: senderNumber.trim(),
          paymentProof: paymentProofUrl || undefined
        }
      },
      {
        onSuccess: () => {
          setIsSuccess(true);
        },
        onError: (error: any) => {
          toast({
            title: "Payment submission failed",
            description: error?.data?.error || error?.message || "Please check the details and try again.",
            variant: "destructive",
          });
        }
      }
    );
  };

  if (isSuccess) {
    return (
      <>
        <main className="flex-1 flex flex-col items-center justify-center p-6 text-center min-h-[80vh]">
          <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mb-6">
            <CheckCircle2 className="w-10 h-10 text-green-500" />
          </div>
          <h1 className="text-2xl font-black mb-2">PAYMENT SUBMITTED</h1>
          <p className="text-muted-foreground mb-8 max-w-sm">
            Your payment is being verified by our admins. Premium access will be granted once approved.
          </p>
          <Button onClick={() => setLocation("/")} className="font-bold">
            RETURN TO HOME
          </Button>
        </main>
        <Navbar />
      </>
    );
  }

  return (
    <>
      <main className="w-full max-w-xl flex-1 pb-24">
        <header className="relative overflow-hidden border-b border-white/10 bg-gradient-to-br from-[#211331] via-[#15121e] to-[#0b0b11] px-4 pb-7 pt-7">
          <div className="absolute -right-16 -top-16 h-40 w-40 rounded-full bg-fuchsia-500/15 blur-3xl" />
          <div className="relative flex items-center gap-3">
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={() => setLocation("/packages", { replace: true })}
              aria-label="Go back"
              className="border-white/15 bg-white/5 text-white hover:bg-white/10"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-fuchsia-300">Premium access</p>
              <h1 className="mt-1 text-2xl font-black tracking-tight text-white">Complete your order</h1>
              <p className="mt-1 text-xs text-zinc-400">পেমেন্ট সাবমিট করতে নিচের ধাপগুলো পূরণ করুন</p>
            </div>
          </div>
          <div className="relative mt-6 flex items-center gap-2 text-[10px] font-bold uppercase tracking-wider">
            <div className="flex items-center gap-1.5 text-fuchsia-300"><span className="flex h-5 w-5 items-center justify-center rounded-full bg-fuchsia-500 text-white">1</span> Plan</div>
            <div className="h-px flex-1 bg-white/15" />
            <div className="flex items-center gap-1.5 text-zinc-400"><span className="flex h-5 w-5 items-center justify-center rounded-full border border-white/20">2</span> Pay</div>
            <div className="h-px flex-1 bg-white/15" />
            <div className="flex items-center gap-1.5 text-zinc-400"><span className="flex h-5 w-5 items-center justify-center rounded-full border border-white/20">3</span> Done</div>
          </div>
        </header>

        {selectedPackage && (
          <div className="mx-4 mt-5 overflow-hidden rounded-2xl border border-fuchsia-400/30 bg-gradient-to-r from-fuchsia-500/15 via-purple-500/10 to-transparent p-4 shadow-[0_0_24px_rgba(192,132,252,0.1)]">
            <div className="flex items-center justify-between gap-3">
              <div className="flex min-w-0 items-center gap-3">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-fuchsia-500/15 text-2xl">👑</div>
                <div className="min-w-0">
                  <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-fuchsia-300">Your selected plan</div>
                  <div className="mt-1 truncate text-lg font-black text-white">{selectedPackage.name.trim()}</div>
                  <div className="text-xs text-zinc-400">{selectedPackage.duration} {selectedPackage.durationUnit} premium access</div>
                </div>
              </div>
              <div className="shrink-0 text-right">
                <div className="text-2xl font-black text-cyan-300">৳{selectedPackage.priceBdt}</div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">Total</div>
              </div>
            </div>
            <div className="mt-4 flex items-center gap-2 border-t border-white/10 pt-3 text-xs text-zinc-400">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              Secure manual verification by our team
            </div>
          </div>
        )}

        <Tabs defaultValue="local" className="mx-4 mb-5 mt-6">
          <TabsList className="grid h-12 w-full grid-cols-2 rounded-xl border border-white/10 bg-white/5 p-1">
            <TabsTrigger value="local" className="gap-2 rounded-lg data-[state=active]:bg-fuchsia-500/20 data-[state=active]:text-fuchsia-200"><Smartphone className="h-4 w-4" /> Local BD</TabsTrigger>
            <TabsTrigger value="global" className="gap-2 rounded-lg data-[state=active]:bg-fuchsia-500/20 data-[state=active]:text-fuchsia-200"><CreditCard className="h-4 w-4" /> Global</TabsTrigger>
          </TabsList>
          
          <TabsContent value="local" className="space-y-3 pt-4">
            {localMethods.map(method => (
              <Card 
                key={method.id} 
                className={`cursor-pointer overflow-hidden transition-all ${selectedMethodId === method.id ? 'border-fuchsia-400/70 bg-fuchsia-500/10 shadow-[0_0_18px_rgba(192,132,252,0.14)]' : 'border-white/10 bg-white/[0.03] hover:border-white/25'}`}
                onClick={() => setSelectedMethodId(method.id)}
              >
                <CardContent className="flex items-center gap-3 p-4">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/10 text-2xl">{method.emoji || "৳"}</div>
                  <div className="flex-1">
                    <div className="font-bold text-white">{method.name}</div>
                    <div className="mt-1 font-mono text-xs tracking-widest text-zinc-400">{method.phoneNumber}</div>
                  </div>
                  {selectedMethodId === method.id && <Check className="h-5 w-5 text-emerald-400" />}
                  <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); handleCopy(method.phoneNumber || ""); }}>
                    <Copy className="w-4 h-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
          
          <TabsContent value="global" className="space-y-3 pt-4">
            {paymentMethods?.filter(m => (m.type === "global" || m.type === "card") && m.isActive).map(method => (
              <Card 
                key={method.id} 
                className={`cursor-pointer overflow-hidden transition-all ${selectedMethodId === method.id ? 'border-fuchsia-400/70 bg-fuchsia-500/10 shadow-[0_0_18px_rgba(192,132,252,0.14)]' : 'border-white/10 bg-white/[0.03] hover:border-white/25'}`}
                onClick={() => setSelectedMethodId(method.id)}
              >
                <CardContent className="flex items-center gap-3 p-4">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/10 text-2xl">{method.emoji || "💳"}</div>
                  <div className="flex-1">
                    <div className="font-bold text-white">{method.name}</div>
                    <div className="mt-1 font-mono text-xs tracking-widest text-zinc-400">{method.phoneNumber}</div>
                  </div>
                  {selectedMethodId === method.id && <Check className="h-5 w-5 text-emerald-400" />}
                  <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); handleCopy(method.phoneNumber || ""); }}>
                    <Copy className="w-4 h-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
            {paymentMethods?.filter(m => (m.type === "global" || m.type === "card") && m.isActive).length === 0 && (
              <div className="text-center py-8 text-muted-foreground">No global methods available</div>
            )}
          </TabsContent>
        </Tabs>

        <div className="mx-4 mb-5 rounded-2xl border border-amber-400/30 bg-amber-400/10 p-4 shadow-[0_0_18px_rgba(251,191,36,0.08)]">
          <div className="flex items-start gap-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-amber-400/15 text-lg">📌</div>
            <div>
              <h3 className="font-black text-amber-200">পেমেন্ট নির্দেশনা</h3>
               <p className="mt-1 whitespace-pre-line text-sm leading-5 text-amber-100/80">
                 {settings?.paymentInstructions?.trim() || "উপরের নম্বরে Send Money করতে হবে। Cash In করবেন না।\nSend Money সম্পন্ন করার পর আপনার Sender Number এবং Transaction ID নিচে দিন।"}
               </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="mx-4 space-y-4">
          <div className="space-y-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4 shadow-xl">
            <div className="flex items-center gap-3 border-b border-white/10 pb-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-cyan-400/10"><WalletCards className="h-5 w-5 text-cyan-300" /></div>
              <div>
                <h3 className="font-bold text-white">Payment details</h3>
                <p className="text-xs text-zinc-500">Enter the details used for your payment</p>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Sender Number *</Label>
              <Input
                required
                value={senderNumber}
                onChange={(e) => setSenderNumber(e.target.value)}
                placeholder="01XXXXXXXXX"
                className="border-white/10 bg-black/20"
              />
            </div>

            <div className="space-y-2">
              <Label>Transaction ID *</Label>
              <Input 
                required 
                value={transactionId} 
                onChange={(e) => setTransactionId(e.target.value)} 
                placeholder="e.g. TRXR123456"
                className="border-white/10 bg-black/20 font-mono uppercase"
              />
            </div>
          </div>

          <Button 
            type="submit" 
            className="h-14 w-full rounded-2xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-pink-600 font-black tracking-wide text-white shadow-[0_8px_24px_rgba(192,38,211,0.28)] transition-all hover:scale-[1.01] hover:from-purple-500 hover:to-pink-500"
             disabled={!selectedMethodId || !selectedPackage || !currentUser || !transactionId.trim() || !senderNumber.trim() || submitPayment.isPending}
          >
            <span>{submitPayment.isPending ? "SUBMITTING..." : "SUBMIT PAYMENT FOR VERIFICATION"}</span>
            {!submitPayment.isPending && <ArrowRight className="ml-2 h-5 w-5" />}
          </Button>
          {!currentUser && (
            <p className="text-center text-xs text-amber-300/80">আপনার অ্যাকাউন্ট লোড হচ্ছে, একটু অপেক্ষা করুন...</p>
          )}
          <p className="flex items-center justify-center gap-1.5 pb-2 text-center text-[11px] text-zinc-500">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" /> Your payment details are handled securely
          </p>
        </form>
      </main>
      <Navbar />
    </>
  );
}
