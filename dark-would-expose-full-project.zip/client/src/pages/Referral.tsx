import { useGetMe, useGetReferralStats, useListPublicReferralSettings, useGetPublicSettings, useListSocialLinks } from "@workspace/api-client-react";
import { Navbar } from "@/components/layout/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Users, Copy, Share2, Gift, ArrowLeft, ChevronRight, ExternalLink, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Referral() {
  const { toast } = useToast();
  const tgId = localStorage.getItem("dwe_user_tg_id") || "";
  const { data: user } = useGetMe({ telegramId: tgId }, { query: { enabled: !!tgId } } as any);
  const { data: refStats } = useGetReferralStats({ telegramId: user?.telegramId || tgId || "" }, { query: { enabled: !!(user?.telegramId || tgId) } } as any);
  const { data: tiers } = useListPublicReferralSettings();
  const { data: settings } = useGetPublicSettings();
  const { data: socialLinks } = useListSocialLinks();

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied to clipboard" });
  };

  const inviteLink = refStats?.referralLink || `https://t.me/darkwould_bot?start=${user?.referralCode}`;
  const currentCount = refStats?.referralCount || 0;

  return (
    <>
      <main className="flex-1 pb-24 md:pb-8 bg-background">
        <header className="p-4 border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-30 flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => window.history.back()}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-bold tracking-tight text-foreground">Invite Friends</h1>
        </header>

        <div className="p-4 max-w-md mx-auto space-y-6 mt-4">
          
          <div className="text-center py-6">
            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Gift className="w-10 h-10 text-primary" />
            </div>
            <h2 className="text-3xl font-black mb-2">Earn Free VIP</h2>
            <p className="text-muted-foreground text-sm max-w-xs mx-auto">
              Invite friends to the bot and earn free premium days automatically when they join.
            </p>
          </div>

          <Card className="border-primary/50 bg-primary/5">
            <CardContent className="p-6">
              <div className="flex gap-2 mb-4">
                <Input readOnly value={inviteLink} className="bg-background border-border font-mono text-xs" />
                <Button size="icon" onClick={() => handleCopy(inviteLink)}>
                  <Copy className="w-4 h-4" />
                </Button>
                <Button size="icon" variant="secondary" onClick={() => handleCopy(inviteLink)}>
                  <Share2 className="w-4 h-4" />
                </Button>
              </div>
              <div className="text-center">
                <span className="text-sm text-muted-foreground">You have invited </span>
                <span className="font-black text-primary text-xl mx-1">{currentCount}</span>
                <span className="text-sm text-muted-foreground"> friends</span>
              </div>
            </CardContent>
          </Card>

          {(socialLinks?.filter((link) => link.isActive).length ?? 0) > 0 && (
            <div className="space-y-3">
              <h3 className="px-1 text-xs font-black uppercase tracking-widest text-muted-foreground">Social Links</h3>
              {socialLinks?.filter((link) => link.isActive).map((link) => (
                <a
                  key={link.id}
                  href={link.url}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/40"
                >
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-secondary">
                    {link.logoUrl ? (
                      <img src={link.logoUrl} alt="" className="h-full w-full object-cover" />
                    ) : (
                      <ExternalLink className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>
                  <span className="flex-1 text-sm font-semibold">{link.displayName}</span>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </a>
              ))}
            </div>
          )}

          {settings?.telegramUsername && (
            <a
              href={`https://t.me/${settings.telegramUsername.replace(/^@/, "")}`}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-3 rounded-xl border border-cyan-400/25 bg-cyan-400/10 p-4 text-cyan-200 transition-colors hover:bg-cyan-400/20"
            >
              <Send className="h-5 w-5 shrink-0" />
              <span className="flex-1 text-sm font-semibold">Contact Content Admin</span>
              <ChevronRight className="h-4 w-4" />
            </a>
          )}

          <h3 className="font-bold tracking-tight text-lg mt-8 mb-4 flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" /> Rewards Tiers
          </h3>
          
          <div className="space-y-3">
            {tiers?.sort((a, b) => a.friendsCount - b.friendsCount).map((tier, i) => {
              const isAchieved = currentCount >= tier.friendsCount;
              const isNext = !isAchieved && (i === 0 || currentCount >= (tiers[i-1]?.friendsCount || 0));
              
              return (
                <div 
                  key={tier.id} 
                  className={`flex items-center justify-between p-4 rounded-xl border transition-colors ${
                    isAchieved ? 'bg-primary/10 border-primary/30' : 
                    isNext ? 'bg-card border-primary/50 shadow-[0_0_15px_rgba(225,29,72,0.1)]' : 
                    'bg-secondary/20 border-border opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-black ${
                      isAchieved ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground'
                    }`}>
                      {tier.friendsCount}
                    </div>
                    <div>
                      <div className="font-bold text-sm">Invite {tier.friendsCount} Friends</div>
                      <div className={`text-xs ${isAchieved ? 'text-primary' : 'text-muted-foreground'}`}>
                        {isAchieved ? 'Reward Unlocked!' : 'Unlock Premium'}
                      </div>
                    </div>
                  </div>
                  <div className={`font-black text-lg ${isAchieved ? 'text-primary' : 'text-muted-foreground'}`}>
                    +{tier.freeDays}d
                  </div>
                </div>
              );
            })}
            
            {tiers?.length === 0 && (
              <div className="text-center py-8 text-muted-foreground border border-dashed border-border rounded-xl">
                Referral program is currently disabled.
              </div>
            )}
          </div>

        </div>
      </main>
      <Navbar />
    </>
  );
}
